% Multi-Parametric Toolbox Graphical User Interface
%   mpt_studio             - MPT Graphical User Interface
%   mpt_setup              - Main MPT configuration rutine
%
% Authors: Michal Kvasnica, Pascal Grieder, Mato Baotic
% kvasnica@control.ee.ethz.ch, grieder@control.ee.ethz.ch, baotic@control.ee.ethz.ch
%
% Copyright (C) 2003-2006 Michal Kvasnica, Pascal Grieder, Mato Baotic
%
% For support, write to: mpt@control.ee.ethz.ch
