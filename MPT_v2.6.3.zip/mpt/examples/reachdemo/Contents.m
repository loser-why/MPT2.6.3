% Multi-Parametric Toolbox Reachability analysis demos
%
%
% reachdemo1   - Reachability analysis demo - Part 1
% reachdemo2   - Reachability analysis demo - Part 2
% verifdemo1   - Verification demo - Part 1
% verifdemo2   - Verification demo - Part 2
%
% Authors: Michal Kvasnica, Pascal Grieder, Mato Baotic
% kvasnica@control.ee.ethz.ch, grieder@control.ee.ethz.ch, baotic@control.ee.ethz.ch
%
% Copyright (C) 2003-2006 Michal Kvasnica, Pascal Grieder, Mato Baotic
%
% For support, write to: mpt@control.ee.ethz.ch
